from pathlib import Path
import math,json,pymxs,traceback
from pymxs import runtime as r
root=Path(r'C:/Users/nyanyameowv/Documents/Codex/2026-11-04/new-chat')
old=root/'outputs/双教学复习/效果工程';out=root/'outputs/双教学复习/完整场景练习';out.mkdir(exist_ok=True)
def rgb(v):return r.Color(v,v,v)
def setup():
 r.resetMaxFile(r.Name('noPrompt'));r.units.SystemType=r.Name('centimeters');r.units.SystemScale=1;r.frameRate=30;r.animationRange=r.interval(0,100)
 ren=r.Arnold();r.renderers.current=ren;ren.AA_samples=3;ren.autodetect_threads=False;ren.threads=8;r.renderWidth=640;r.renderHeight=480;r.backgroundColor=rgb(0)
def material(name,v,metal=0):
 m=r.ai_standard_surface(name=name);m.base=.8;m.base_color=rgb(v);m.metalness=metal;m.specular=.4;m.specular_roughness=.3;return m
def stage():
 # A documented supplemental cyclorama, not a claim to decode the source Loft001.
 profile=[(-600,0),(400,0)]+[(400+200*math.sin(i*math.pi/32),200-200*math.cos(i*math.pi/32)) for i in range(1,17)]+[(600,800)]
 verts=[r.Point3(x,y,z) for y,z in profile for x in [-800,800]];faces=[]
 for j in range(len(profile)-1):
  a=j*2+1;faces.extend([r.Point3(a,a+1,a+2),r.Point3(a+1,a+3,a+2)])
 room=r.mesh(name='Room_FILLED_cyclorama',vertices=r.Array(*verts),faces=r.Array(*faces));room.material=material('Room_Arnold_gray_FILLED',110)
 key=r.Arnold_Light(name='Arnold_Quad_FILLED_position',pos=r.Point3(-250,-150,500));key.shapeType=3;key.quadX=100;key.quadY=100;key.spread=1;key.intensity=500;key.exposure=6;key.dir=r.Point3(-250,-150,400)
 cam=r.Physical(name='PhysCamera_Study_FILLED_target',pos=r.Point3(375.779,-699.973,268.641));cam.targeted=False;cam.dir=r.Point3(375.779,-699.973,148.641);cam.film_width_mm=36;cam.specify_fov=True;cam.fov=45;cam.f_number=8
 r.SceneExposureControl.exposureControl=r.Physical_Camera_Exposure_Control();cam.exposure_gain_type=1;cam.exposure_value=16
 r.viewport.setCamera(cam)
 return room,key,cam
def save(name,cam,frame=40):
 r.sliderTime=frame;r.saveMaxFile(str(out/(name+'.max')))
 data={'file':name+'.max','frame_to_view':frame,'camera':{'name':cam.name,'position':[cam.pos.x,cam.pos.y,cam.pos.z],'fov':cam.fov,'film_width_mm':cam.film_width_mm,'f_number':cam.f_number,'target_EV_FILLED':cam.exposure_value},'lights':[{'name':l.name,'shapeType':l.shapeType,'intensity':l.intensity,'exposure':l.exposure,'normalize':l.normalize,'on':l.on} for l in r.lights],'objects':[{'name':o.name,'class':str(r.classOf(o)),'position':[o.pos.x,o.pos.y,o.pos.z]} for o in r.objects],'note':'Room dimensions, light placement, exposure and camera aim are supplemental; video values are labelled by time in the full course, not an entire final scene copied.'}
 (out/(name+'_场景清单.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
 r.render(camera=cam,outputfile=str(out/(name+'_批处理校验.png')),vfb=False)
def main():
 setup();room,key,cam=stage()
 for x,metal in [(-170,1),(0,0),(170,0)]:
  s=r.Sphere(name='Study_Sphere_'+str(x),radius=75,segs=48,pos=r.Point3(x,0,75),mapcoords=True);s.material=material('Sphere_'+str(x),180 if metal else 60,metal)
 save('10_从零搭建弧形舞台与物理镜头',cam)
 setup();room,key,cam=stage();cam.exposure_value=0;key.exposure=-10;fire=r.loadTempMaterialLibrary(str(old/'02_火焰平面_原生渐变.mat'))[0]
 obj=r.Plane(name='Fire_Plane_500x350',width=500,length=350,widthsegs=1,lengthsegs=1,pos=r.Point3(0,0,187.925));obj.rotation=r.EulerAngles(-90,0,0);obj.material=fire;obj.castShadows=False;obj.receiveShadows=False
 cam.pos=r.Point3(0,-1000,230);cam.dir=r.Point3(0,-1000,42.075)
 save('11_火焰片进入完整舞台',cam,35)
 setup();room,key,cam=stage();cam.exposure_value=10;key.exposure=0;orb=r.loadTempMaterialLibrary(str(old/'07_紫金能量球.mat'))[0]
 for c in r.getClassInstances(r.Cellular):
  if '#63' in c.name:c.size=70;c.coords.Tiling=r.Point3(1,1,.2)
 for x,mat in [(-200,material('Metal_comparison',180,1)),(0,material('Dark_comparison',20)),(220,orb)]:
  s=r.GeoSphere(name='Compare_'+str(x),radius=100,segs=32,pos=r.Point3(x,0,100),mapcoords=True);s.material=mat
 cam.pos=r.Point3(375.779,-1100,330);cam.dir=r.Point3(375.779,-1100,210)
 save('12_材质比较与相机透视实验',cam)
 setup();room,key,cam=stage();key.on=False;cam.exposure_value=7
 ball=r.Sphere(name='Ball',radius=40,segs=64,mapcoords=True,pos=r.Point3(0,65.956,40));ball.material=r.loadTempMaterialLibrary(str(old/'08_冲击能量团.mat'))[0]
 # Remove the previous creative falling/flattening action: this scene teaches geometry and map layering.
 nm=r.NoiseModifier();nm.seed=0;nm.scale=100;nm.fractal=True;nm.roughness=0;nm.iterations=6;nm.strength=r.Point3(20,20,0);nm.animate=True;nm.frequency=.25;r.addModifier(ball,nm)
 cyl=r.Cylinder(name='Cylinder001',radius=60.038,height=77.227,sides=64,heightsegs=1,capsegs=1,mapcoords=True,pos=r.Point3(0,65.956,0));r.convertToPoly(cyl)
 r.execute('o=getNodeByName "Cylinder001";cf=#{};for f=1 to polyop.getNumFaces o where abs((polyop.getFaceNormal o f).z)>0.9 do cf[f]=true;polyop.deleteFaces o cf')
 cyl.material=r.loadTempMaterialLibrary(str(old/'03_青色螺旋气流_原生渐变.mat'))[0]
 taper=r.Taper();taper.amount=1;taper.curve=0;r.addModifier(cyl,taper)
 with pymxs.animate(True):
  for f,s in [(0,(.36,.36,.0864)),(15,(.36,.36,.0864)),(70,(.36,.36,.46224))]:
   with pymxs.attime(f):cyl.scale=r.Point3(*s)
  for f,z in [(0,0),(15,0),(40,0),(75,37.8),(100,40)]:
   with pymxs.attime(f):ball.pos=r.Point3(0,65.956,z)
 cam.pos=r.Point3(170,-280,160);cam.dir=r.Point3(170,-345.956,120)
 save('13_球体Noise与Taper气流组合',cam,40)
 setup();room,key,cam=stage();key.on=False;cam.exposure_value=6
 tube=r.Cylinder(name='Cylinder001_MeshEmitter',radius=28.399,height=291.01,sides=12,heightsegs=1,capsegs=1,mapcoords=True,pos=r.Point3(144.665,-239.677,266.114));tube.rotation=r.EulerAngles(0,90,0);r.convertToPoly(tube)
 uv=r.Unwrap_UVW();r.addModifier(tube,uv)
 light=r.Arnold_Light(name='ArnoldLight002_Mesh');light.shapeType=8;light.lightMesh=tube;light.intensity=1;light.exposure=2;light.normalize=False
 noise=r.Noise(name='Noise15_FILLED');noise.size=100;noise.coords.coordType=0;noise.color1=r.Color(255,100,10);noise.color2=r.Color(40,80,255);light.useTexmap=True;light.texmap=noise
 ball=r.Sphere(name='Receiver_Ball_FILLED',radius=90,segs=48,pos=r.Point3(0,0,90));ball.material=material('MeshLight_receiver',120)
 cam.pos=r.Point3(700,-1100,500);cam.dir=r.Point3(600,-1000,350)
 save('14_实体圆柱与Arnold_Mesh灯',cam)
 (out/'场景构建完成.txt').write_text('5 scenes saved and rendered. Batch previews may carry Arnold license watermark. Source dimensions and supplemental dimensions are separated in the website.',encoding='utf-8')
try:main()
except:(out/'构建错误.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
