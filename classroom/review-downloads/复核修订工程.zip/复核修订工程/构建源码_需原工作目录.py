from pathlib import Path
import json,math,traceback,pymxs
from pymxs import runtime as r
root=Path(r'C:/Users/nyanyameowv/Documents/Codex/2026-11-04/new-chat')
exec((root/'work/build_full_stage.py').read_text(encoding='utf-8').split('try:main()')[0])
out=root/'outputs/双教学复习/复核修订工程';out.mkdir(exist_ok=True)
previous=root/'outputs/双教学复习/完整场景练习'
manifest=[]
def vec(p):return [float(p.x),float(p.y),float(p.z)]
def load(folder,prefix):
 r.units.SystemType=r.Name('centimeters');r.units.SystemScale=1
 r.units.DisplayType=r.Name('metric');r.units.MetricType=r.Name('centimeters')
 r.loadMaxFile(str(next(folder.glob(prefix+'*.max'))),quiet=True)
def finish(name,cam,frame,changes,limits):
 r.sliderTime=frame;r.viewport.setCamera(cam);r.renderWidth=640;r.renderHeight=480
 r.renderers.current.AA_samples=3;r.renderers.current.autodetect_threads=False;r.renderers.current.threads=8
 r.saveMaxFile(str(out/(name+'.max')))
 entry={'name':name,'camera':cam.name,'visible_frame':frame,'changes':changes,'remaining_differences':limits}
 manifest.append(entry)
 (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
 r.render(camera=cam,outputfile=str(out/(name+'_校验.png')),vfb=False)
 (out/(name+'_定位.ms')).write_text('(\nsliderTime='+str(frame)+'\nlocal c=getNodeByName "'+cam.name+'"\nif c!=undefined do viewport.setCamera c\nredrawViews()\n)\n',encoding='utf-8-sig')
def setscale(node,keys):
 r.setPropertyController(node,r.Name('scale'),r.Bezier_Scale())
 with pymxs.animate(True):
  for f,values in keys:
   with pymxs.attime(f):node.scale=r.Point3(*values)
def main():
 load(old,'01_圆柱碎片消散');obj=r.getNodeByName('Cylinder001')
 erosion=next(c for c in r.getClassInstances(r.Cellular) if '#12' in c.name)
 with pymxs.animate(True):
  for f in range(101):
   with pymxs.attime(f):
    v=255+(184.930-255)*(f/50.)**2 if f<=50 else max(0,184.930*(1-(f-50)/48.))
    erosion.divColor1=r.Color(v,v,v)
 # The existing frame-sampled expansion was confirmed by four newly read intermediate values.
 r.rendNThFrame=3;r.animationRange=r.interval(0,100)
 cam=next(c for c in r.cameras if str(r.classOf(c))!='Targetobject')
 finish('15_圆柱扩张_多点曲线核对',cam,40,['0–100帧缩放，60/68/86/94帧分别126/134.64/147.06/149.46%，吻合原工程拟合。','Cellular边界颜色1最终可见中键50帧184.930，替换旧48帧189.720。','每3帧输出640×480，原片AVI压缩器为未压缩。'],['视口坐标未展示，保留自选检查相机。','边界颜色1右端98帧0为图读；曲线切线未展示，仍用采样拟合。'])
 load(previous,'11_');obj=r.getNodeByName('Fire_Plane_500x350');obj.name='Plane001';obj.primaryVisibility=True;obj.secondaryVisibility=False;obj.castShadows=False;obj.receiveShadows=False
 c=next(t for t in r.getClassInstances(r.Cellular) if '#1 ' in t.name)
 with pymxs.animate(True):
  with pymxs.attime(0):c.coords.offset=r.Point3(0,0,0)
  with pymxs.attime(100):c.coords.offset=r.Point3(0,-150,100)
 cam=r.getNodeByName('PhysCamera_Study_FILLED_target')
 # Keep the source light's readable position in a disabled comparison object; aim is not known.
 source=r.Arnold_Light(name='SOURCE_v04_ArnoldLight001_AIM_UNKNOWN',pos=r.Point3(707.468,-1299.118,292.297));source.shapeType=3;source.quadX=100;source.quadY=100;source.intensity=500;source.exposure=6;source.normalize=False;source.on=False
 finish('16_火焰_最终偏移与可见性修订',cam,35,['Cellular#1第100帧Offset改为(0,-150,100)。','平面宽500长350，Z187.925，关闭反射折射可见及投接影。','保存原片主灯位置和参数为关闭的对照灯，避免未知朝向影响预览。'],['背景、检查相机和曝光仍为补齐；原片主灯目标坐标未知。','初始Offset及切线未完整展示。'])
 load(previous,'12_');preview=r.getNodeByName('PhysCamera_Study_FILLED_target');preview.name='Supplemental_Overview'
 for node,x in zip([r.getNodeByName('Compare_-200'),r.getNodeByName('Compare_0'),r.getNodeByName('Compare_220')],[-400,-50,300]):
  node.radius=150;node.pos=r.Point3(x,153.769,306.417)
 target=r.Targetobject(name='PhysCamera001.Target',pos=r.Point3(-47.887,153.769,306.417))
 cam=r.Physical(name='PhysCamera001',pos=r.Point3(-535.458,-882.38,268.641));cam.targeted=True;cam.target=target
 cam.film_width_mm=36;cam.specify_fov=True;cam.fov=45;cam.f_number=8;cam.use_dof=False;cam.zoom_factor=1;cam.motion_blur_enabled=False;cam.exposure_value=10
 helper=r.Point(name='Point001',pos=r.Point3(459.874,-17.81,185.942));helper.size=150
 finish('17_物理相机_末段机位与目标',cam,0,['采用v09最终机位(-535.458,-882.38,268.641)。','Target=(-47.887,153.769,306.417)，连续操作与1145.75距离共同支持。','实际创建可选的相机Target；36mm、FOV45、f8、DOF关闭。','补入Point001位置及显示尺寸150。'],['机位和目标不是同帧双读，属于连续证据组合。','为匹配此镜头补齐三球布局：半径150、X=-400/-50/300、Y153.769、Z306.417；这些不是老师球体读值。','舞台与曝光仍补齐，不能保证构图完全同老师。','Supplemental_Overview保留为辅助镜头。'])
 load(previous,'13_');ball=r.getNodeByName('Ball');cyl=r.getNodeByName('Cylinder001');cyl.pos=r.Point3(.535,67.243,0)
 fade=next(m for m in r.getClassInstances(r.ColorCorrection) if m.name=='VisibilityEnvelope_FILLED')
 with pymxs.animate(True):
  for f in range(101):
   with pymxs.attime(f):
    a=0 if f<=15 or f>=64 else ((f-15)/15 if f<=30 else ((64-f)/34)**2)
    fade.color=rgb(255*a)
 setscale(cyl,[(15,(.35597,.35597,.08405)),(70,(1.09643,1.09643,1.44879))])
 setscale(ball,[(15,(.5,.5,0)),(75,(1.5,1.5,1.2))])
 r.setPropertyController(ball,r.Name('position'),r.Position_XYZ())
 with pymxs.animate(True):
  for f,z in [(15,0),(35,-.002),(40,0),(45,7.702),(74,36.287),(75,38)]:
   with pymxs.attime(f):ball.pos=r.Point3(0,65.956,z)
 nm=next(m for m in ball.modifiers if str(r.classOf(m)).lower()=='noisemodifier');nm.animate=True;nm.frequency=.25
 r.setPropertyController(nm,r.Name('phase'),r.Linear_Float())
 with pymxs.animate(True):
  with pymxs.attime(0):nm.phase=0
  with pymxs.attime(100):nm.phase=100
 taper=next(m for m in cyl.modifiers if str(r.classOf(m))=='Taper');taper.amount=1;taper.curve=0;taper.primaryaxis=2;taper.effectaxis=2
 with pymxs.attime(63):
  local_gizmo=r.Point3(.535,67.243,37.841)*r.inverse(cyl.objectTransform)
  taper.gizmo.position=local_gizmo
 cam=r.getNodeByName('PhysCamera_Study_FILLED_target')
 finish('18_球体与气流_关键帧及Gizmo修订',cam,35,['Cylinder位置(.535,67.243,0)。','精确Scale键15帧(35.597,35.597,8.405)%；70帧(109.643,109.643,144.879)%。','Ball补上图读Scale50/50/0→150/150/120%，末端Z38；以35帧-.002、45帧7.702、74帧36.287约束位置拟合。','Noise Phase按时间0→100线性变化，保留45帧45、61帧61的关系。','Taper按63帧世界Gizmo高度37.841反算局部值，局部='+str(vec(local_gizmo))],['Ball缩放值为曲线图读，切线仍自选；新增位置采样键用于拟合，不是声称老师原关键帧时间。','Gizmo局部值取决于自选缩放插值；匹配63帧显示位置不保证整段形变完全一致。','背景、相机、曝光仍补齐。旧Ball材质中的补充遮罩尚非全节点逐值恢复。'])
 load(previous,'14_');tube=r.getNodeByName('Cylinder001_MeshEmitter');tube.renderable=False
 light=r.getNodeByName('ArnoldLight002_Mesh');n=r.ai_noise(name='Noise15_Arnold_SOURCE');n.octaves=1;n.lacunarity=1.92;n.distortion=0;n.amplitude=1;n.scale=r.Point3(1,1,1);n.offset=r.Point3(0,0,0);n.p=r.Point3(0,0,0);n.time=0;n.coord_space=1;n.pref_name='Pref';n.mode=0;n.color1=rgb(0);n.color2=rgb(255);light.texmap=n;light.useTexmap=True
 cam=r.getNodeByName('PhysCamera_Study_FILLED_target')
 finish('19_网格灯_ArnoldNoise实验时点',cam,40,['Noise15改为Arnold ai_noise，Octaves1/Lacunarity1.92/Distortion0/Amplitude1，Object坐标、Scale1、Offset0、P0、Time0。','圆柱Renderable关闭；保留Mesh引用、Intensity1、Exposure2、Normalize关闭。','此文件仅复现v06网格灯实验阶段；课程末尾灯被移除。'],['UV编辑器确有调整，但顶点数值未显示；当前保留默认UV，未称布局一致。','Noise黑白按色块与默认值补齐，未打开RGB窗口。','场景和相机仍补齐。'])
 load(old,'05_Arnold_Gobo');light=r.getNodeByName('ArnoldLight001');light.pos=r.Point3(0,0,125.536);light.rotation=r.EulerAngles(0,0,0)
 other=r.instance(light);other.name='ArnoldLight002';other.pos=light.pos;other.rotation=r.EulerAngles(0,-180,0)
 cam=r.getNodeByName('Study_Camera_FILLED')
 finish('20_Gobo_反向实例双灯',cam,30,['原灯位置(0,0,125.536)、旋转(0,0,0)。','通过实例复制建立第二盏灯，旋转(0,-180,0)，共享灯参数与Gobo链。','两灯同位置依Shift原地旋转操作链推断。'],['Intensity200/Exposure6沿用早段读值，末段面板未重开。','接收面、比较球和检查相机仍为补充；不是老师棚景尺寸复刻。'])
 # Independently reopen each saved file and sample actual objects and animation.
 results=[]
 for entry in manifest:
  load(out,entry['name'])
  d={'file':entry['name']+'.max','system_units':str(r.units.SystemType),'system_scale':r.units.SystemScale,'renderer':str(r.classOf(r.renderers.current)),'samples':[],'lights':[],'cameras':[]}
  for f in [0,15,35,40,45,50,60,61,63,68,70,74,75,86,94,100]:
   with pymxs.attime(f):
    row={'frame':f,'nodes':{}}
    for name in ['Cylinder001','Ball','Plane001']:
     node=r.getNodeByName(name)
     if node:
      row['nodes'][name]={'pos':vec(node.pos),'scale':vec(node.scale)}
      for m in node.modifiers:
       if str(r.classOf(m))=='Taper':row['nodes'][name]['gizmo_world']=vec(m.gizmo.position*node.objectTransform)
       if str(r.classOf(m)).lower()=='noisemodifier':row['nodes'][name]['noise_phase']=float(m.phase)
    for c in r.getClassInstances(r.Cellular):
     if c.name=='#1 Cellular':row['fire_offset']=vec(c.coords.offset)
     if '#12' in c.name:row['erosion_divColor1']=float(c.divColor1.r)
    d['samples'].append(row)
  for l in r.lights:
   if r.isProperty(l,'shapeType'):d['lights'].append({'name':l.name,'position':vec(l.pos),'rotation':str(r.quatToEuler(l.rotation)),'shape':l.shapeType,'texture_class':str(r.classOf(l.texmap)) if l.texmap else None,'mesh':l.lightMesh.name if l.lightMesh else None})
  for c in r.cameras:
   if r.isProperty(c,'fov'):d['cameras'].append({'name':c.name,'pos':vec(c.pos),'target':vec(c.target.pos) if c.target else None,'fov':c.fov})
  if entry['name'].startswith('20_'):d['lights_instanced']=bool(r.areNodesInstances(r.getNodeByName('ArnoldLight001'),r.getNodeByName('ArnoldLight002')))
  results.append(d)
  (out/'保存后读回.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
try:main()
except:
 (out/'构建错误.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
