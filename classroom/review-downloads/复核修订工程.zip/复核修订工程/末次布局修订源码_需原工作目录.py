from pathlib import Path
import json,math
from pymxs import runtime as r
root=Path(r'C:/Users/nyanyameowv/Documents/Codex/2026-11-04/new-chat');out=root/'outputs/双教学复习/复核修订工程'
r.units.SystemType=r.Name('centimeters');r.units.SystemScale=1
p=next(out.glob('17_*.max'));r.loadMaxFile(str(p),quiet=True)
for node,x in zip([r.getNodeByName('Compare_-200'),r.getNodeByName('Compare_0'),r.getNodeByName('Compare_220')],[-350,-50,300]):node.radius=135;node.pos=r.Point3(x,153.769,306.417)
cam=r.getNodeByName('PhysCamera001');r.saveMaxFile(str(p));r.render(camera=cam,outputfile=str(out/(p.stem+'_校验.png')),vfb=False)
manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'));manifest[2]['remaining_differences'][1]='为匹配此镜头补齐三球布局：半径135、X=-350/-50/300、Y153.769、Z306.417；这些不是老师球体读值。'
p=next(out.glob('19_*.max'));r.loadMaxFile(str(p),quiet=True);tube=r.getNodeByName('Cylinder001_MeshEmitter');poly=tube.baseObject
uvs=[];faces=[]
for f in range(1,r.polyop.getNumFaces(poly)+1):
 vs=[r.polyop.getVert(poly,i) for i in r.polyop.getFaceVerts(poly,f)];normal=r.polyop.getFaceNormal(poly,f);face=[]
 if abs(normal.z)>.9:
  center=.25 if normal.z<0 else .75
  points=[(center+.18*v.x/28.399,.8+.18*v.y/28.399) for v in vs]
 else:
  angles=[math.atan2(v.y,v.x)%(2*math.pi) for v in vs]
  if max(angles)-min(angles)>math.pi:angles=[a+2*math.pi if a<math.pi else a for a in angles]
  points=[(.05+.9*a/(2*math.pi),.05+.5*v.z/291.01) for a,v in zip(angles,vs)]
 for u,v in points:uvs.append(r.Point3(u,v,0));face.append(len(uvs))
 faces.append(face)
r.polyop.setMapSupport(poly,1,True);r.polyop.setNumMapVerts(poly,1,len(uvs),keep=False)
for i,v in enumerate(uvs,1):r.polyop.setMapVert(poly,1,i,v)
for i,f in enumerate(faces,1):r.polyop.setMapFace(poly,1,i,r.Array(*f))
r.update(tube);r.saveMaxFile(str(p))
manifest[4]['changes'].append('按原片布局近似整理UV：矩形侧壁在下、两端盖并排在上；数值为自选，非逐顶点恢复。')
manifest[4]['remaining_differences'][0]='UV已匹配侧壁与端盖布局关系，但原片顶点数值未显示；当前UV坐标为补齐。'
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
# Read back the saved layout and export a diagram from its actual UV values.
r.loadMaxFile(str(p),quiet=True);poly=r.getNodeByName('Cylinder001_MeshEmitter').baseObject
polygons=[]
for f in range(1,r.polyop.getNumFaces(poly)+1):
 points=[r.polyop.getMapVert(poly,1,i) for i in r.polyop.getMapFace(poly,1,f)]
 polygons.append([[v.x,v.y] for v in points])
(out/'UV布局读回.json').write_text(json.dumps({'channel':1,'status':'layout approximation; vertex coordinates self-chosen','polygons':polygons},indent=2),encoding='utf-8')
svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 640"><rect width="600" height="640" fill="#f3f2eb"/><text x="25" y="28" font-size="18">Mesh light UV — layout approximation</text><rect x="50" y="70" width="500" height="500" fill="white" stroke="#718c85"/>'
for ps in polygons:svg+='<polygon points="'+' '.join(f'{50+x*500:.2f},{570-y*500:.2f}' for x,y in ps)+'" fill="#badbd0" fill-opacity=".4" stroke="#246a62" stroke-width="1.5"/>'
svg+='<text x="50" y="615" font-size="15">Read back from saved .max / map channel 1</text></svg>'
(out/'19_UV布局读回.svg').write_text(svg,encoding='utf-8')
